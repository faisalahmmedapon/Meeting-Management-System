<?php $__env->startSection('title'); ?>
    Role Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6 col-md-12 col-lg-12 d-flex justify-content-end">
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-outline-success px-5 radius-30"> <i
                            class="fa fa-list"> Role Lists </i> </a>

                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Info boxes -->
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Opps!</strong> Something went wrong, please check below errors.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="row  py-5">

                <div class="col-12 col-sm-6 col-md-8 mx-auto">
                    <div class=" p-3">
                        <form action="<?php echo e(route('roles.update', $role->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group p-2">
                                <label for="name"> Name: </label>
                                <input type="text" name="name" class="form-control" value="<?php echo e($role->name); ?>" id="name">
                            </div>


                            <div class="form-group p-2">
                                <label for="password_confirmation"> Permission: </label>
                                <br>
                                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check form-check-inline">

                                        <input
                                            <?php echo e(in_array($value->id, $rolePermissions) ? 'checked' : ''); ?> name="permission[]"
                                            class="form-check-input" type="checkbox" value="<?php echo e($value->id); ?>"
                                            id="permission<?php echo e($value->id); ?>">
                                        <label class="form-check-label" for="permission<?php echo e($value->id); ?>">
                                            <?php echo e($value->name); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="form-group p-2">
                                <button type="submit" class="btn btn-success px-5"><i class="fa ">Submit</i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->

        </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\social-media\resources\views/backend/roles/edit.blade.php ENDPATH**/ ?>