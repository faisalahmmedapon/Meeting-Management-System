<?php $__env->startSection('title'); ?>
    Roles
<?php $__env->stopSection(); ?>



<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="d-flex justify-content-between">
        <h6 class="mb-0 text-uppercase"> Permissions </h6>
        <span class="badge bg-success"><a href="<?php echo e(route('roles.create')); ?>"> New Roles </a></span>

    </div>
    <hr/>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="example2" class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>


                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($role->id); ?></td>
                            <td> <span class="badge bg-success"> <?php echo e($role->name ?? ''); ?> </span>
                             </td>
                            <td class="d-flex">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
                                    <a href="<?php echo e(route('roles.edit',$role->id)); ?>" class="btn btn-sm"><i
                                            class="lni lni-highlight-alt"></i></a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                                    <a href="<?php echo e(route('roles.show',$role->id)); ?>" class="btn btn-sm"><i
                                            class="lni lni-eye"></i></a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                                    <form method="POST"
                                          action="<?php echo e(route('roles.destroy',$role->id)); ?>"
                                          onsubmit="return confirm('Are you sure ?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm" type="submit"><i class="lni lni-cross-circle"></i>
                                        </button>

                                    </form>
                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>



<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\social-media\resources\views/backend/roles/index.blade.php ENDPATH**/ ?>