<?php $__env->startSection('title'); ?>
    Admins
<?php $__env->stopSection(); ?>



<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">
        <h6 class="mb-0 text-uppercase"> Admins </h6>
        <span class="badge bg-success"><a href="<?php echo e(route('admins.create')); ?>"> New Admin </a></span>
    </div>

    <hr />
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="example2" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role Names</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($admin->name); ?></td>
                                <td><?php echo e($admin->email); ?></td>
                                <td>

                                    <?php $__currentLoopData = $admin->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <span class="badge bg-success"> <?php echo e($adminName ?? ''); ?> </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </td>
                                <td class="d-flex">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-list')): ?>
                                        <a href="<?php echo e(route('admins.edit', $admin->id)); ?>" class="btn btn-sm"><i
                                                class="lni lni-highlight-alt"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-edit')): ?>
                                        <a href="<?php echo e(route('admins.show', $admin->id)); ?>" class="btn btn-sm"><i
                                                class="lni lni-eye"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-delete')): ?>
                                        <form method="POST" action="<?php echo e(route('admins.destroy', $admin->id)); ?>"
                                            onsubmit="return confirm('Are you sure ?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm" type="submit"><i class="lni lni-cross-circle"></i>
                                            </button>

                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Action</th>

                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\social-media\resources\views/backend/admins/index.blade.php ENDPATH**/ ?>