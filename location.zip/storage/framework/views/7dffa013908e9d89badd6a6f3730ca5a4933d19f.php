<footer class="page-footer">
    <p class="mb-0">Copyright © 2021. All right reserved.</p>
</footer>
<?php /**PATH C:\laragon\www\LEARN LARAVEL\social-media\resources\views/backend/layouts/partials/footer.blade.php ENDPATH**/ ?>