<div class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
        <div>
            <img src="<?php echo e(asset('backend')); ?>/assets/images/logo-icon.png" class="logo-icon" alt="logo icon">
        </div>
        <div>
            <h4 class="logo-text">Rocker</h4>
        </div>
        <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
        </div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">
        <li>
            <a href="<?php echo e(route('dashboard')); ?>" class="has-arrow">Dashboard</a>
        </li>
        

        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-cog bx-spin"></i>
                </div>
                <div class="menu-title">Settings</div>
            </a>
            <ul>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
                    <li><a href="<?php echo e(route('roles.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Roles</a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-list')): ?>
                    <li><a href="<?php echo e(route('permissions.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Permissions</a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-list')): ?>
                    <li><a href="<?php echo e(route('admins.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Admins</a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agent-list')): ?>
                    <li><a href="<?php echo e(route('agents.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Agents</a>
                    </li>
                <?php endif; ?>

            </ul>
        </li>

    </ul>
    <!--end navigation-->
</div>
<?php /**PATH C:\laragon\www\LEARN LARAVEL\social-media\resources\views/backend/layouts/partials/siteber.blade.php ENDPATH**/ ?>